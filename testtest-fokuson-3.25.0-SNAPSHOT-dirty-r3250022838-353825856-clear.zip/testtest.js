(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
/**
 * Created by tmalthesen on 11/05/16.
 */

"use strict";

module.exports = function (React, ReactDOM, ReactComponents, widget) {
  var Text = ReactComponents.Text;
  return React.createClass({
    mixins: [ReactComponents.mixins.rootMixin(widget)],

    getInitialState: function getInitialState() {
      return {};
    },

    componentWillMount: function componentWillMount() {
      var _this = this;

      // This is call when historyBack is called on the widget. The state returned is what was popped from the history stack.
      // To added something to the history stack call widget.pushHistory(state).
      widget.historyPopped = function (state) {
        // set the state returned from the history stack on the React component.
        _this.state = state;
        _this.setState(state);
      };
    },

    render: function render() {
      return React.createElement(
        Text,
        null,
        "Test"
      );
    }
  });
};

},{}],2:[function(require,module,exports){
/**
 * Created by tmalthesen on 11/05/16.
 */

"use strict";

module.exports = {
  // put logic here

};

},{}],3:[function(require,module,exports){
/* global fokusEnv, Logger, FokusOn*/
/* jslint white:false, browser:true*/

'use strict';

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

var _componentsTesttestRootJsx = require('./components/testtestRoot.jsx');

var _componentsTesttestRootJsx2 = _interopRequireDefault(_componentsTesttestRootJsx);

var _controllersTesttestControllerJs = require('./controllers/testtestController.js');

var _controllersTesttestControllerJs2 = _interopRequireDefault(_controllersTesttestControllerJs);

fokusEnv.define('testtest', ['FokusOn', 'ReactWidget', 'React', 'ReactDOM', 'ReactComponentsFactory'], function (FokusOn, ReactWidget, React, ReactDOM, ReactComponentsFactory) {
  return ReactWidget.extend({
    initialize: function initialize(initParams) {
      // call the parents of ReactWidget's initialize function with the initParams
      this.parent(initParams);
      // Load the css for current skin of the widget
      this.loadCSS('testtest.css');

      // Load the language file for the widget
      this.getResourceAsJson('resources/language.json', this.setProperties.bind(this), function (message) {
        Logger.error('NOT able to load resource for widget (' + this.initParams.id + '). ', message);
      }, false);

      // Load the options file for the current skin of the widget
      this.getResourceAsJson('skins/' + this.initParams.skinName + '/options.json', (function (options) {
        this.setOptions(options);
      }).bind(this), Class.empty, true);
    },
    render: function render() {
      if (!$defined($(this.initParams.id))) {
        // Inject the widgets root DOM element in to the DOM tree
        this.injectInWidgetsContainer();

        // Get a instant of the ReactComponents by pass in the widget, This is done so the components can use the widgets function like getProps()
        var ReactComponents = ReactComponentsFactory(this);

        // Get the Root react element
        var Root = (0, _componentsTesttestRootJsx2['default'])(React, ReactDOM, ReactComponents, this);

        // Render first React component to the widget root DOM element
        this.renderReactRoot(React.createElement(Root, null));
      } else {}
    }

  });
});

},{"./components/testtestRoot.jsx":1,"./controllers/testtestController.js":2}]},{},[3]);
