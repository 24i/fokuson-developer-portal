# testtest

## Summary
testtesttest

## Configuration

#### *Skinning*
**File location:** &lt;widgetRoot&gt;/skins/../../options.json

**Options:**
###### backButton:
XXX

###### disableMultiTab:
XXX